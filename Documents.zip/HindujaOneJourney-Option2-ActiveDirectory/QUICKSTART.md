# HindujaOneJourney — Option 2 — Active Directory login (via the backend)

This package contains the Flask backend, the shared journey screens and this
option's two pages: `frontend/ad/portal.html` (customers, served at `/`)
and `frontend/ad/admin.html` (admin console, served at `/admin`,
separate sign-in).

## Run it

1. `cd backend && python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`
2. `cp .env.dev.example .env.dev` and fill in `SECRET_KEY` and the `LDAP_*` values
   (LDAPS URL, UPN suffix, base DN, admin group DN — see `docs/SETUP.md` §3).
3. `python run.py` → customer portal http://127.0.0.1:5000/ · admin console http://127.0.0.1:5000/admin

Try it before AD is ready: set `AUTH_MODE=dev` (with `APP_ENV=development`) and sign
in with the users in `DEV_USERS`. Dev mode refuses to start in production.

Tests: `cd backend && python -m pytest`

`.env.dev` holds your secrets and must never be committed or shared
(`.gitignore` already excludes it).

## More
- `docs/SETUP.md` — full setup for this option, production checklist, and how
  admin changes reach customers without a redeploy.
- `docs/INTEGRATION.md` — API list and the mock adapters IT replaces
  (SOAP rating, HR profile data, KYC, payment, policy admin).

All rates, policy numbers and integrations in this package are mocks.
