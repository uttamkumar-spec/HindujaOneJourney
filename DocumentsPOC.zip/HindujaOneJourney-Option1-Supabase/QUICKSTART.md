# HindujaOneJourney — Option 1 — Supabase login

This package contains the Flask backend, the shared journey screens and this
option's two pages: `frontend/supabase/portal.html` (customers, served at `/`)
and `frontend/supabase/admin.html` (admin console, served at `/admin`,
separate sign-in).

## Run it

1. Create users in your Supabase project (Dashboard → Authentication → Users).
2. Make admins: run the SQL in `docs/SETUP.md` §2 for each admin's e-mail.
3. `cd backend && python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`
4. `cp .env.dev.example .env.dev` and fill in `SECRET_KEY`, `SUPABASE_URL`, `SUPABASE_ANON_KEY`
   (and `SUPABASE_JWT_SECRET` only for legacy HS256 projects).
5. `python run.py` → customer portal http://127.0.0.1:5000/ · admin console http://127.0.0.1:5000/admin

Tests: `cd backend && python -m pytest`

`.env.dev` holds your secrets and must never be committed or shared
(`.gitignore` already excludes it).

## More
- `docs/SETUP.md` — full setup for this option, production checklist, and how
  admin changes reach customers without a redeploy.
- `docs/INTEGRATION.md` — API list and the mock adapters IT replaces
  (SOAP rating, HR profile data, KYC, payment, policy admin).

All rates, policy numbers and integrations in this package are mocks.
